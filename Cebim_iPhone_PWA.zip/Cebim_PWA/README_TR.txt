CEBİM – iPHONE ANA EKRAN UYGULAMASI PAKETİ

Bu klasör, Cebim'in PWA (ana ekrana eklenebilen web uygulaması) dosyalarını içerir:
- index.html: uygulama
- manifest.webmanifest: ana ekran/uygulama tanımı
- sw.js: çevrimdışı önbellek
- icon-192.png ve icon-512.png: uygulama simgeleri

ÖNEMLİ:
Bu dosyalar iPhone Dosyalar uygulamasından doğrudan açılarak tam PWA olarak kurulamaz. iOS ana ekrana ekleme ve çevrimdışı çalışma için bu dosyaların HTTPS kullanan bir web adresinde yayınlanması gerekir. Bu ZIP kendi başına bir web adresi oluşturmaz.

YAYINLAMA SONRASI iPHONE KURULUMU:
1. Safari'de yayınlanan HTTPS adresini aç.
2. Paylaş düğmesine bas.
3. “Ana Ekrana Ekle”yi seç.
4. Ekle'ye bas.

VERİLER:
Uygulama kayıtları tarayıcı localStorage alanında tutulur. Tarayıcı verilerini silmek veya farklı tarayıcı/cihaz kullanmak kayıtları etkileyebilir. Ayarlar bölümünden düzenli JSON yedeği al.

CANLI ALTIN/GÜMÜŞ:
Canlı fiyatlar için geçerli API erişimi ve doğru bağlantı ayarları gerekir. Bu paket tek başına Harem Altın API anahtarı sağlamaz; canlı fiyat bağlantısı gerçek API erişimiyle ayrıca test edilmelidir.
